//============================================================================
// Name        : Exceptions.cpp
// Author      : Amber Caldwell
// Version     : 1.0
// Copyright   : Your copyright notice
// Description : Overflows / Underflows in C++, Ansi-style
//============================================================================

// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;

//CREATION OF CUSTOM EXCEPTION -- INHERITS FROM STD::EXCEPTION
class CustomException: virtual public std::exception {
protected:
	std::string error_message;

public:
	explicit
	CustomException(const std::string&msg):
		error_message(msg)
		{}

	virtual ~CustomException() throw() {}

	virtual const char* what() const throw() {
		return error_message.c_str();
	}
};

bool do_even_more_custom_application_logic()
{
  // TODO: Throw any standard exception

	///////////////////////////////
	//THROWING STANDARD EXCEPTION//
	///////////////////////////////
	char a = 1;
	int b = 1;

	if(a == b) {
		throw std::exception(); //CHAR DOES NOT EQUAL INT
	}

	std::cout << "Running Even More Custom Application Logic." << std::endl;

	return true;
}

void do_custom_application_logic()
{
  // TODO: Wrap the call to do_even_more_custom_application_logic()
  //  with an exception handler that catches std::exception, displays
  //  a message and the exception.what(), then continues processing
  std::cout << "Running Custom Application Logic." << std::endl;

  //////////////////////////////////
  //WRAPPING CALL WITH TRY & CATCH//
  //////////////////////////////////
  try {
	  //TRY BLOCK
	if(do_even_more_custom_application_logic()) {
		std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
	}
  }
  //EXCEPTION STATEMENT
  catch (const std::exception& exception) {
		std::cerr << "Exception: " << exception.what() << endl;
  }

  /////////////////////////////
  //THROWING CUSTOM EXCEPTION//
  /////////////////////////////
	int c = 3;
	const char * d = "cat";

	if(strlen(d) == c) {
		throw(CustomException("Custom Error: Try Again")); //does not include null pointer
	}

  // TODO: Throw a custom exception derived from std::exception
  //  and catch it explictly in main

  std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
  // TODO: Throw an exception to deal with divide by zero errors using
  //  a standard C++ defined exception

	//////////////////////////////////////////
	//THROW RUNTIME ERROR FOR DIVIDE BY ZERO//
	//////////////////////////////////////////
	if (den == 0) {
		throw std::runtime_error("Math error: Divided by Zero");
	}

  return (num / den);
}

void do_division() noexcept
{
  //  TODO: create an exception handler to capture ONLY the exception thrown
  //  by divide.

  float numerator = 10.0f;
  float denominator = 0;

  	//////////////////////////////////////////
  	//TRY & CATCH HANDLER FOR DIVIDE BY ZERO//
  	//////////////////////////////////////////
	try {
		//TRY BLOCK
		 auto result = divide(numerator, denominator);
		 std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;

	}
	//EXCEPTION STATEMENT
	catch(const std::runtime_error& e){
		std::cout << "Exception: " << e.what() << std::endl;
	}


}

int main()
{
  std::cout << "Exceptions Tests!" << std::endl;

  // TODO: Create exception handlers that catch (in this order):
  //  your custom exception
  //  std::exception
  //  uncaught exception
  //  that wraps the whole main function, and displays a message to the console.

  ///////////////////////////////////
  //TRY & CATCH - MULTIPLE HANDLERS//
  ///////////////////////////////////
  try {
	  //TRY BLOCK
	  do_division();
	  do_custom_application_logic();
  }
  //CUSTOM EXCEPTION FIRST
  catch (const CustomException& my) {
	  std::cout << my.what() << std::endl;
  }
  //STD::EXCEPTION SECOND
  catch (const std::exception& exc) {
	  std::cout << exc.what() << std::endl;
  }
  //UNCAUGHT EXCEPTIONS LAST
  catch (...) {
	  std::cout << "Uncaught Exception" << std::endl;
  }
  //RETURN INT (INT MAIN)
  return 0;

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
